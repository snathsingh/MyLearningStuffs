In order to build the projects in this solution, you will need to enable the nuget package restore feature.  For instructions on how to do this, see: 

http://docs.nuget.org/docs/workflows/using-nuget-without-committing-packages

