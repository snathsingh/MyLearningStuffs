In order to build the projects in this solution, you will need to enable the nuget package restore feature.  For instructions on how to do this, see: 

http://docs.nuget.org/docs/workflows/using-nuget-without-committing-packages

Using the Twilio appender will require you to configure your own Twilio developer account.  You can do this at no cost at http://www.twilio.com.  Once you have your account information, change the configuration of the Twilio appender to use your account sid, token, and custom phone numbers.
