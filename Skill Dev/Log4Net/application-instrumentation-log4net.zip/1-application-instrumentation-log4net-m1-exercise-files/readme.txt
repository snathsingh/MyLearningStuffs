In order to build the projects in this solution, you will need to enable the nuget package restore feature.  For instructions on how to do this, see: 

http://docs.nuget.org/docs/workflows/using-nuget-without-committing-packages

Building the project named AOP will require you to have a license for PostSharp.  The evaluation license will work fine, and you will be offered the chance to sign up for the license during the build.
